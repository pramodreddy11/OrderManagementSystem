﻿
using Microsoft.Extensions.Primitives;
using OrderManagementSystem.CustomClass;
using OrderManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Web.Http;

namespace OrderManagementSystem.Controllers
{
    public class OrderController : ApiController
    {
        //creating an instance
        OrderManagementSystemEntities orderModel = new OrderManagementSystemEntities();


        [Route("api/get-all-itemsDetails")]
        [HttpGet]
        public HttpResponseMessage GetItems()
        {
            try
            {
                var Response = Request.CreateResponse(HttpStatusCode.OK, orderModel.sp_get_itemDetails().ToList());
                return Response;
            }
            catch
            {
                var Response = Request.CreateResponse(HttpStatusCode.NotFound, "Not found");
                return Response;
            }
        }

        [Route("api/get-user-info")]
        [HttpGet]
        public HttpResponseMessage GetUserInfo()
        {
            try
            {
                var Response = Request.CreateResponse(HttpStatusCode.OK, orderModel.sp_get_userInfo().ToList());
                return Response;
            }
            catch
            {
                var Response = Request.CreateResponse(HttpStatusCode.NotFound, "Not found");
                return Response;
            }
        }
        [Route("api/get-Status-info")]
        [HttpGet]
        public HttpResponseMessage GetStatusDetails()
        {
            try {
                var Response = Request.CreateResponse(HttpStatusCode.OK, orderModel.sp_get_StatusDetails().ToList());
                return Response;
            }
            catch
            {
                var Response = Request.CreateResponse(HttpStatusCode.NotFound, "Not found");
                return Response;

            }
        }
        [Route("api/upsertOrder")]
        [HttpPost]
        public HttpResponseMessage UpsertOrder([FromBody] ItemClass OrderDetails)
        {
            try {
                int List;
                Random r = new Random();
                if (OrderDetails.orderID == 0)
                {
                    var orderItemDetails = orderModel.sp_getOrderDetails().ToList();
                    foreach (var ele in orderItemDetails)
                    {
                        if (ele.OrderStatus == OrderDetails.orderStatus && ele.userId == OrderDetails.userId)
                        {
                            return Request.CreateResponse(HttpStatusCode.NotAcceptable, "There Is an active order to this existing customer please update the order");

                        }
                    }
                    orderModel.sp_upsert_orderDetails(0, OrderDetails.orderPrice, OrderDetails.orderStatus, OrderDetails.userId);
                    List = Convert.ToInt32(orderModel.sp_get_OrderID().FirstOrDefault());

                    foreach (var ele in OrderDetails.Items)
                    {
                        int num = r.Next(1000);

                        orderModel.sp_insert_items_OrderitemsDetails(List, ele.itemID, ele.itemquantity, num);

                    }
                    var Response = Request.CreateResponse(HttpStatusCode.OK, "order Created Successfully");
                    return Response;
                }
                else
                {
                    orderModel.sp_upsert_orderDetails(OrderDetails.orderID, OrderDetails.orderPrice, OrderDetails.orderStatus, OrderDetails.userId);
                    var Response = Request.CreateResponse(HttpStatusCode.OK, "order Updated Successfully");
                    return Response;

                }
            }
            catch
            {
                var Response = Request.CreateResponse(HttpStatusCode.NotFound, "Not found");
                return Response;
            }
        }

        [Route("api/get-all-order-Details")]
        [HttpGet]
        public HttpResponseMessage GetOrderDetails()
        {
            try
            {
                var re = Request;
                var headers = re.Headers;
                var apiKey = Request.Headers.GetValues("role").FirstOrDefault();
                if (apiKey == "admin")
                {
                    var List = orderModel.sp_AllOrderDetails().ToList();
                    List<ItemsOrdered> AdminorderedItems = new List<ItemsOrdered>();
                    List<ItemsOrdered> UserorderedItems = new List<ItemsOrdered>();
                    List<string> AdminItemsOrdered = new List<string>();
                    List<string> userItemsOrdered = new List<string>();
                    List<getItemList> CompleteOrderDetails = new List<getItemList>();
                    foreach (var ele in List)
                    {
                        if (ele.userName == "admin")
                        {
                            AdminorderedItems.Add(new ItemsOrdered { itemName = ele.itemName });
                        }
                        if (ele.userName == "user")
                        {
                            UserorderedItems.Add(new ItemsOrdered { itemName = ele.itemName });
                        }

                    }
                    CompleteOrderDetails.Add(new getItemList { userName = "Admin", ItemsOrdered = AdminorderedItems, ItemStatus = "Pending" });
                    CompleteOrderDetails.Add(new getItemList { userName = "User", ItemsOrdered = UserorderedItems, ItemStatus = "Pending" });
                    var Response = Request.CreateResponse(HttpStatusCode.OK, CompleteOrderDetails);
                    return Response;
                }

                else
                {
                    var Response = Request.CreateResponse(HttpStatusCode.Unauthorized, "Your are Not Athorized");
                    return Response;
                }
            }
            catch
            {
                var Response = Request.CreateResponse(HttpStatusCode.Unauthorized, "Your are Not Athorized");
                return Response;
            }
        }
        [Route("api/get-Specific-order-Details")]
        [HttpPost]
        public HttpResponseMessage GetSpecDetails([FromBody] getItemList username)
        {
            try {
                var List = orderModel.sp_getspecific_OrderDetails(username.userName).ToList();
                List<ItemsOrdered> orderedItems = new List<ItemsOrdered>();
                List<getItemList> CompleteOrderDetails = new List<getItemList>();
                foreach (var ele in List)
                {
                    orderedItems.Add(new ItemsOrdered { itemName = ele.itemName });
                }
                CompleteOrderDetails.Add(new getItemList { userName = username.userName, ItemsOrdered = orderedItems, ItemStatus = "Pending" });
                var Response = Request.CreateResponse(HttpStatusCode.OK, CompleteOrderDetails);
                return Response;
            }
            catch
            {
                var Response = Request.CreateResponse(HttpStatusCode.Unauthorized, "Your are Not Athorized");
                return Response;

            }
    }
    

}
}
