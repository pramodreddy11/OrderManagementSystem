﻿using OrderManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrderManagementSystem.CustomClass
{
    public class ItemClass
    {

        public int orderID { get; set; }
        public int orderPrice { get; set; }
        public int orderStatus { get; set; }
        public int userId { get; set; }
        public List<insertItems> Items { get; set; }
    }
   
    public class insertItems
    {
        public int orderID { get; set; }
        public int itemID { get; set; }
        public int itemquantity { get; set; }
        public int orderitemID { get; set; }


    }

    public class ItemsOrdered
    {
        public string itemName { get; set; }
        
    }

    public class getItemList
    {
        public string userName { get; set; }
        public List<ItemsOrdered> ItemsOrdered{get;set;}

        public string ItemStatus { get; set; }


    }
}